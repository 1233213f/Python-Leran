passwd={"China":"BigCountry","Korean":"SmallCountry","France":"MediumCounty"}
print(passwd)